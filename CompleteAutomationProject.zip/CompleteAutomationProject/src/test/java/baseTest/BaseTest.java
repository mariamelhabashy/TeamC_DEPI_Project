package baseTest;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import pages.HomePage;
import java.time.Duration;

public class BaseTest {
    protected WebDriver driver;
    protected HomePage homePage;

   @BeforeMethod
   public void setUp() {
       driver = new ChromeDriver();
       driver.manage().window().maximize();
       driver.get("https://bstackdemo.com/");
       homePage = new HomePage(driver);
   }

    @AfterMethod
    public void tearDown() {
        if (driver != null) driver.quit();
    }
}
