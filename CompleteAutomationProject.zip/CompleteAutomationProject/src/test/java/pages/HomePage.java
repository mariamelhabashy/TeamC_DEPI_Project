package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class HomePage {

    WebDriver driver;
    WebDriverWait wait;

    By signInButton = By.id("signin");
    private final By cartButton = By.xpath("//div[contains(@class, 'bag--float-cart')]");
    private final By addToCartButtons = By.className("shelf-item__buy-btn");
    private final By productTitles = By.className("shelf-item__title");

    By searchBox = By.cssSelector(".px-4.py-1.border.border-gray-300.rounded-l");
    By searchButton = By.cssSelector(".px-4.py-1.bg-gray-100.border.border-l-0.border-gray-300");
    By sortDropdown = By.cssSelector(".sort select");
    By filterSidebar = By.className("checkmark");
    By productPrices = By.xpath("//div[@class='val']//b");
    By userName = By.className("username");
    By favSection = By.linkText("/favourites");
    By ordersSection = By.linkText("/orders");
    By offersSection = By.linkText("/offers");
    By favButton = By.tagName("path");

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void sortLowestToHighest() {
        Select sort = new Select(driver.findElement(sortDropdown));
        sort.selectByValue("lowestprice");
    }

    public void sortHighestToLowest() {
        Select sort = new Select(driver.findElement(sortDropdown));
        sort.selectByValue("highestprice");
    }

    public LoginPage clickSignIn() {
        driver.findElement(signInButton).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("react-select-2-input")));
        return new LoginPage(driver);
    }

    public LoginPage clickLogout() {
        if (!isUserLoggedIn()) {
            throw new IllegalStateException("Cannot logout because no user is logged in.");
        }
        driver.findElement(signInButton).click();
        return new LoginPage(driver);
    }

    public boolean isUserLoggedIn() {
        return !driver.findElements(userName).isEmpty();
    }

    public String getLoggedInUsername() {
        return driver.findElement(userName).getText();
    }

    public void searchProduct(String productName) {
        WebElement search = driver.findElement(searchBox);
        search.clear();
        search.sendKeys(productName);
        driver.findElement(searchButton).click();
    }

    public void clickCart() {
        driver.findElement(cartButton).click();
    }

    public CartPage openCart() {
        if (driver.findElements(By.className("float-cart__content")).isEmpty()) {
            clickCart();
        }
        return new CartPage(driver);
    }

    public void closeCart() {
        try {
            WebElement closeBtn = driver.findElement(By.className("float-cart__close-btn"));
            if (closeBtn.isDisplayed()) {
                closeBtn.click();
                Thread.sleep(500);
            }
        } catch (Exception e) {
        }
    }

    public void addProductByName(String name) {

        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(productTitles, 0));
        wait.until(ExpectedConditions.numberOfElementsToBeMoreThan(addToCartButtons, 0));

        List<WebElement> products = driver.findElements(productTitles);
        List<WebElement> buttons = driver.findElements(addToCartButtons);

        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getText().equalsIgnoreCase(name)) {
                buttons.get(i).click();
                break;
            }
        }
    }

    public void filterByBrand(String brand) {
        List<WebElement> brands = driver.findElements(filterSidebar);
        for (WebElement b : brands) {
            if (b.getText().equalsIgnoreCase(brand)) {
                b.click();
                break;
            }
        }
    }

    public void addFirstProductToCart() {
        driver.findElements(addToCartButtons).get(0).click();
    }

    public String getProductPrice() {
        return driver.findElements(productPrices).get(0).getText();
    }

    public String getProductTitle() {
        return driver.findElements(productTitles).get(0).getText();
    }

    public List<Integer> getAllProductPrices() {
        List<WebElement> priceElements = driver.findElements(productPrices);
        List<Integer> prices = new ArrayList<>();

        for (WebElement price : priceElements) {
            String text = price.getText().trim();
            text = text.replaceAll("[^0-9]", "");
            prices.add(Integer.parseInt(text));
        }

        return prices;
    }

    public boolean isSortedAscending() {
        List<Integer> prices = getAllProductPrices();

        for (int i = 0; i < prices.size() - 1; i++) {
            if (prices.get(i) > prices.get(i + 1)) {
                return false;
            }
        }

        return true;
    }

    public boolean isSortedDescending() {
        List<Integer> prices = getAllProductPrices();

        for (int i = 0; i < prices.size() - 1; i++) {
            if (prices.get(i) < prices.get(i + 1)) {
                return false;
            }
        }

        return true;
    }

    public List<String> getAllProductTitles() {
        List<WebElement> products = driver.findElements(productTitles);
        List<String> titles = new ArrayList<>();

        for (WebElement product : products) {
            titles.add(product.getText());
        }

        return titles;
    }

    public boolean allProductsBelongToBrand(String brand) {
        List<String> titles = getAllProductTitles();

        for (String title : titles) {
            if (brand.equalsIgnoreCase("Apple") && !title.toLowerCase().contains("iphone")) {
                return false;
            }

            if (brand.equalsIgnoreCase("Samsung") && !title.toLowerCase().contains("galaxy")) {
                return false;
            }

            if (brand.equalsIgnoreCase("Google") && !title.toLowerCase().contains("pixel")) {
                return false;
            }

            if (brand.equalsIgnoreCase("OnePlus") && !title.toLowerCase().contains("oneplus")) {
                return false;
            }
        }

        return true;
    }

    public boolean searchResultsContain(String keyword) {
        List<String> titles = getAllProductTitles();

        for (String title : titles) {
            if (!title.toLowerCase().contains(keyword.toLowerCase())) {
                return false;
            }
        }

        return true;
    }
}