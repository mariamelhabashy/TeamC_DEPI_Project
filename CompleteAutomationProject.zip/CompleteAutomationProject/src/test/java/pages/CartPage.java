package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class CartPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void clearCartCompletely() {
        List<WebElement> deleteButtons = driver.findElements(By.xpath("//div[contains(@class, 'shelf-item__del')]"));
        while (!deleteButtons.isEmpty()) {
            deleteButtons.get(0).click();
            try { Thread.sleep(500); } catch (InterruptedException e) {}
            deleteButtons = driver.findElements(By.xpath("//div[contains(@class, 'shelf-item__del')]"));
        }
    }

    public void changeQuantity(String productName, String operation, int times) {
        //By btn = By.xpath("//p[text()='" + productName + "']/ancestor::div[contains(@class, 'shelf-item')]//button[text()='" + operation + "']");
        By btn = By.xpath(
                "//p[contains(@class,'title') and normalize-space()='" + productName + "']" +
                        "/ancestor::div[contains(@class,'shelf-item')]" +
                        "//button[normalize-space()='" + operation + "']");
        for (int i = 0; i < times; i++) {
            //wait.until(ExpectedConditions.elementToBeClickable(btn)).click();
            WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(btn));

            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", button);

            wait.until(ExpectedConditions.elementToBeClickable(button));

            button.click();
            try { Thread.sleep(1500); } catch (InterruptedException e) {}
        }
    }

    public void removeProduct(String productName) {
        By delBtn = By.xpath("//p[text()='" + productName + "']/ancestor::div[contains(@class, 'shelf-item')]//div[contains(@class, 'shelf-item__del')]");
        //wait.until(ExpectedConditions.elementToBeClickable(delBtn)).click();
        WebElement button = wait.until(ExpectedConditions.visibilityOfElementLocated(delBtn));

        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", button);

        wait.until(ExpectedConditions.elementToBeClickable(button));

        button.click();
    }

    public String getSubtotal() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("sub-price__val"))).getText();
    }

    public void clickCheckoutRedirectCheckoutPage() {
        wait.until(ExpectedConditions.elementToBeClickable(By.className("buy-btn"))).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("firstNameInput")));
    }
    public void clickCheckoutRedirectLoginPage() {
        wait.until(ExpectedConditions.elementToBeClickable(By.className("buy-btn"))).click();

        wait.until(ExpectedConditions.urlContains("signin"));
    }
}

