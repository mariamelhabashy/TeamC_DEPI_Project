package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
    WebDriver driver;
    By firstName=By.id("firstNameInput");
    By lastName=By.id("lastNameInput");
    By address=By.id("addressLine1Input");
    By state=By.id("provinceInput");
    By postalCode=By.id("postCodeInput");
    By submitButton=By.id("checkout-shipping-continue");
    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
    }
    public void enterFirstName(String name) {
        driver.findElement(firstName).clear();
        driver.findElement(firstName).sendKeys(name);
    }

    public void enterLastName(String name) {
        driver.findElement(lastName).clear();
        driver.findElement(lastName).sendKeys(name);
    }

    public void enterAddress(String add) {
        driver.findElement(address).clear();
        driver.findElement(address).sendKeys(add);
    }

    public void enterState(String stateName) {
        driver.findElement(state).clear();
        driver.findElement(state).sendKeys(stateName);
    }

    public void enterPostalCode(String postal) {
        driver.findElement(postalCode).clear();
        driver.findElement(postalCode).sendKeys(postal);
    }

    public void fillShippingForm(String fname, String lname, String addr, String stateName, String zip) {
        enterFirstName(fname);
        enterLastName(lname);
        enterAddress(addr);
        enterState(stateName);
        enterPostalCode(zip);
    }

    public OrderConfirmationPage continueCheckout() {
        driver.findElement(submitButton).click();
        return new OrderConfirmationPage(driver);
    }



}
