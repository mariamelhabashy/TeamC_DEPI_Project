package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {

    WebDriver driver;


    private By usernameInput = By.id("react-select-2-input");
    private By passwordInput = By.id("react-select-3-input");
    By usernameDropdown = By.cssSelector("#username svg");
    By passwordDropdown = By.cssSelector("#password svg");

    private By loginButton = By.id("login-btn");

    private By errorMessage = By.className("api-error");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public  HomePage login(String username, String password) {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(ExpectedConditions.elementToBeClickable(usernameDropdown)).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'" + username + "')]"))).click();


        wait.until(ExpectedConditions.elementToBeClickable(passwordDropdown)).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(text(),'" + password + "')]"))).click();


        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();


        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.className("username")));

        return new HomePage(driver);
    }
    public LoginPage loginInvalidUser(String username, String password) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


        wait.until(ExpectedConditions.elementToBeClickable(usernameDropdown)).click();
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//div[contains(text(),'" + username + "')]")
        )).click();


        wait.until(ExpectedConditions.elementToBeClickable(passwordDropdown)).click();
        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//div[contains(text(),'" + password + "')]"))).click();


        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage));

        return this;
    }

    public boolean isErrorMessageDisplayed() {
        return !driver.findElements(errorMessage).isEmpty();
    }

    public String getErrorMessage() {
        if (isErrorMessageDisplayed()) {
            return driver.findElement(errorMessage).getText();
        }
        return "";
    }
}