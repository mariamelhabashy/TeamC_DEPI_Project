package tests;

import baseTest.BaseClassTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.CartPage;

public class ProductTest extends BaseClassTest {

    @Test
    public void verifyProductTitle() {
        HomePage home = new HomePage(driver);
        String actualTitle = home.getProductTitle();
        Assert.assertEquals(actualTitle, "iPhone 12");
    }

    @Test
    public void verifyProductPrice() {
        HomePage home = new HomePage(driver);
        String actualPrice = home.getProductPrice();
        Assert.assertEquals(actualPrice, "799");
    }

    @Test
    public void addFirstProductToCart() {
        HomePage home = new HomePage(driver);
        home.addFirstProductToCart();
        CartPage cart = home.openCart();
        Assert.assertNotNull(cart);
    }

    @Test
    public void addSpecificProduct() {
        HomePage home = new HomePage(driver);
        home.addProductByName("iPhone 12");
        CartPage cart = home.openCart();
        Assert.assertNotNull(cart);
    }

    @Test
    public void verifyProductAddedToCart() {
        HomePage home = new HomePage(driver);
        home.addProductByName("iPhone 12");
        CartPage cart = home.openCart();
        String subtotal = cart.getSubtotal();
        Assert.assertNotNull(subtotal);
    }
}
