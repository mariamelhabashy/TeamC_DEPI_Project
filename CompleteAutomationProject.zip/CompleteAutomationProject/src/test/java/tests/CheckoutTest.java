package tests;

import baseTest.BaseTest;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import pages.*;

public class CheckoutTest extends BaseTest {
    private CheckoutPage goToCheckout() {
        LoginPage loginPage = homePage.clickSignIn();
        homePage = loginPage.login("demouser", "testingisfun99");
        homePage.addProductByName("iPhone 12");

        CartPage cart = homePage.openCart();

        cart.clickCheckoutRedirectCheckoutPage();
        return new CheckoutPage(driver);
    }
    @Test
    public void successfulCheckoutAndConfirmation() {

        CheckoutPage checkout = goToCheckout();

        checkout.fillShippingForm(
                "Yara",
                "Sameh",
                "Miami",
                "Alexandria",
                "11111");

        OrderConfirmationPage confirmation =
                checkout.continueCheckout();

        Assert.assertEquals(
                confirmation.getSuccessMessage(),
                "Your Order has been successfully placed."
        );
    }
    @Test
    public void checkoutWithoutFirstName() {

        CheckoutPage checkout = goToCheckout();

        checkout.fillShippingForm(
                "",
                "Sameh",
                "Miami",
                "Alexandria",
                "11111");

        checkout.continueCheckout();

        String message = driver.findElement(By.id("firstNameInput"))
                .getAttribute("validationMessage");

        Assert.assertEquals(message, "Please fill in this field.");
    }
    @Test
    public void checkoutWithoutLastName() {

        CheckoutPage checkout = goToCheckout();

        checkout.fillShippingForm(
                "Yara",
                "",
                "Miami",
                "Alexandria",
                "11111");

        checkout.continueCheckout();
        String message = driver.findElement(By.id("lastNameInput"))
                .getAttribute("validationMessage");

        Assert.assertEquals(message, "Please fill in this field.");
    }
    @Test
    public void checkoutWithoutAddress() {

        CheckoutPage checkout = goToCheckout();

        checkout.fillShippingForm(
                "Yara",
                "Sameh",
                "",
                "Alexandria",
                "11111");

        checkout.continueCheckout();
        String message = driver.findElement(By.id("addressLine1Input"))
                .getAttribute("validationMessage");

        Assert.assertEquals(message, "Please fill in this field.");
    }
    @Test
    public void checkoutWithoutState() {

        CheckoutPage checkout = goToCheckout();

        checkout.fillShippingForm(
                "Yara",
                "Sameh",
                "Miami",
                "",
                "11111");

        checkout.continueCheckout();
        String message = driver.findElement(By.id("provinceInput"))
                .getAttribute("validationMessage");

        Assert.assertEquals(message, "Please fill in this field.");
    }
    @Test
    public void checkoutWithoutPostalCode() {

        CheckoutPage checkout = goToCheckout();

        checkout.fillShippingForm(
                "Yara",
                "Sameh",
                "Miami",
                "Alexandria",
                "");

        checkout.continueCheckout();
        String message = driver.findElement(By.id("postCodeInput"))
                .getAttribute("validationMessage");
        Assert.assertEquals(message, "Please fill in this field.");
    }
    @Test
    public void continueShoppingReturnsToProductsPage() {

        CheckoutPage checkout = goToCheckout();
        checkout.fillShippingForm(
                "Yara",
                "Sameh",
                "Miami",
                "Alexandria",
                "11111");
        checkout.continueCheckout();
        //driver.findElement(By.xpath("//button[contains(text(),'Continue Shopping')]")).click();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement continueShopping = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.xpath("//button[contains(.,'Continue Shopping')]")
                )
        );

        continueShopping.click();

        Assert.assertTrue(
                driver.findElement(By.xpath("//div[text()='Products']")).isDisplayed(),
                "Products page was not displayed."
        );
    }
}
