package tests;

import baseTest.BaseClassTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;

public class FilterTest extends BaseClassTest {

    @Test
    public void filterByBrand() throws InterruptedException {
        HomePage home = new HomePage(driver);

        home.filterByBrand("Apple");
        Thread.sleep(2000);
        Assert.assertTrue(home.allProductsBelongToBrand("Apple"),
                "Apple products are not displayed after filtering.");
    }

    @Test
    public void sortLowestToHighest() throws InterruptedException {

        HomePage home = new HomePage(driver);

        home.sortLowestToHighest();
        Thread.sleep(2000);
        Assert.assertTrue(home.isSortedAscending());
    }

    @Test
    public void sortHighestToLowest() throws InterruptedException {

        HomePage home = new HomePage(driver);

        home.sortHighestToLowest();
        Thread.sleep(2000);
        Assert.assertTrue(home.isSortedDescending());
    }

    @Test  //Fail
    public void searchProduct() throws InterruptedException {

        HomePage home = new HomePage(driver);
        home.searchProduct("iPhone");
        Thread.sleep(4000);
        Assert.assertTrue(home.searchResultsContain("iPhone"),
                "Some search results do not match the keyword.");
    }
}
