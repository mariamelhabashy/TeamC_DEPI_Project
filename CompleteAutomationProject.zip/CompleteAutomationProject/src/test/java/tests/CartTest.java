package tests;
import baseTest.BaseClassTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CartPage;

public class CartTest extends BaseClassTest {

    private void cleanStart() throws InterruptedException {
        Thread.sleep(500);
        homePage.openCart();
        new CartPage(driver).clearCartCompletely();
        homePage.closeCart();
        Thread.sleep(1000);
    }

    @Test(priority = 1)
    public void addProductsToCart() throws InterruptedException {
        cleanStart();
        homePage.addProductByName("iPhone 12");
        Thread.sleep(1500);
        homePage.addProductByName("iPhone 12 Mini");
        Thread.sleep(1000);
        homePage.openCart();
    }


    @Test(priority = 2)
    public void adjustQuantities() {
        CartPage cart = new CartPage(driver);

        cart.changeQuantity("iPhone 12", "+", 2);
        cart.changeQuantity("iPhone 12 Mini", "+", 1);
    }

    @Test(priority = 3)
    public void modifyCartItems() throws InterruptedException {
        CartPage cart = new CartPage(driver);
        cart.changeQuantity("iPhone 12", "-", 1);
        Thread.sleep(1000);
        cart.removeProduct("iPhone 12 Mini");
    }


    @Test(priority = 4)
    public void checkoutRequiresLogin() {

        homePage.openCart();

        CartPage cart = new CartPage(driver);

        Assert.assertNotNull(cart.getSubtotal(), "Cart should not be empty.");

        cart.clickCheckoutRedirectLoginPage();

        Assert.assertTrue(driver.getCurrentUrl().contains("signin"),
                "Guest user should be redirected to login page.");
    }
}