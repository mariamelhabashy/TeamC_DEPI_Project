package tests;

import baseTest.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

public class LoginTest extends BaseTest {

    @Test(priority = 1)
    public void validLogin1() {

        LoginPage loginPage = homePage.clickSignIn();
        HomePage home = loginPage.login("demouser", "testingisfun99");

        Assert.assertTrue(home.isUserLoggedIn());
        Assert.assertEquals(home.getLoggedInUsername(), "demouser");
    }
    @Test(priority = 2)
    public void validLogin2() {

        LoginPage loginPage = homePage.clickSignIn();
        HomePage home = loginPage.login("image_not_loading_user", "testingisfun99");

        Assert.assertTrue(home.isUserLoggedIn());
        Assert.assertEquals(home.getLoggedInUsername(), "image_not_loading_user");
    }
    @Test(priority = 3)
    public void validLogin3() {

        LoginPage loginPage = homePage.clickSignIn();
        HomePage home = loginPage.login("existing_orders_user", "testingisfun99");

        Assert.assertTrue(home.isUserLoggedIn());
        Assert.assertEquals(home.getLoggedInUsername(), "existing_orders_user");
    }
    @Test(priority = 4)
    public void validLogin4() {

        LoginPage loginPage = homePage.clickSignIn();
        HomePage home = loginPage.login("fav_user", "testingisfun99");

        Assert.assertTrue(home.isUserLoggedIn());
        Assert.assertEquals(home.getLoggedInUsername(), "fav_user");
    }
    @Test(priority = 5)
    public void lockedUser() {

        LoginPage loginPage = homePage.clickSignIn();
        loginPage.loginInvalidUser("locked_user", "testingisfun99");

        Assert.assertTrue(loginPage.isErrorMessageDisplayed());
        Assert.assertEquals(loginPage.getErrorMessage(), "Your account has been locked.");
    }

    /*@Test(priority = 2)
    public void invalidUsername() {

        LoginPage loginPage = homePage.clickSignIn();
        loginPage.login("wrongusername", "testingisfun99");

        Assert.assertTrue(loginPage.isErrorMessageDisplayed());
        Assert.assertEquals(loginPage.getErrorMessage(), "Invalid Username");
    }

    @Test(priority = 3)
    public void invalidPassword() {

        LoginPage loginPage = homePage.clickSignIn();
        loginPage.login("demouser", "wrongpassword");

        Assert.assertTrue(loginPage.isErrorMessageDisplayed());
        Assert.assertEquals(loginPage.getErrorMessage(), "Invalid Password");
    }

    @Test(priority = 4)
    public void emptyUsername() {

        LoginPage loginPage = homePage.clickSignIn();
        loginPage.login("", "testingisfun99");

        Assert.assertTrue(loginPage.isErrorMessageDisplayed());
    }

    @Test(priority = 5)
    public void emptyPassword() {

        LoginPage loginPage = homePage.clickSignIn();
        loginPage.login("demouser", "");

        Assert.assertTrue(loginPage.isErrorMessageDisplayed());
    }*/


}